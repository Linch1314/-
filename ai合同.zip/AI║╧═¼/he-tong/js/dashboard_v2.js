 Chart.defaults.font.family = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'";
        Chart.defaults.responsive = true; Chart.defaults.maintainAspectRatio = false;
        const weeklyCtx = document.getElementById('weeklyContractsChart')?.getContext('2d');
        if (weeklyCtx) new Chart(weeklyCtx, { type: 'bar', data: { labels: ['一', '二', '三', '四', '五', '六', '日'], datasets: [{ label: '起草数', data: [12, 19, 3, 5, 2, 3, 9], backgroundColor: '#0052cc', barPercentage: 0.6 }] }, options: { scales: { y: { beginAtZero: true, display:false }, x:{ display:false } }, plugins: { legend: { display: false } } } });
        const monthlyCtx = document.getElementById('monthlyReviewsChart')?.getContext('2d');
        if (monthlyCtx) new Chart(monthlyCtx, { type: 'line', data: { labels: ['W1', 'W2', 'W3', 'W4'], datasets: [{ label: '审查数', data: [20, 35, 28, 37], borderColor: '#28a745', tension: 0.3, fill: true, backgroundColor: 'rgba(40, 167, 69, 0.1)', pointRadius:0 }] }, options: { scales: { y: { beginAtZero: true, display:false }, x:{ display:false } }, plugins: { legend: { display: false } } } });
        const typeDistCtx = document.getElementById('contractTypeDistributionChart')?.getContext('2d');
        if (typeDistCtx) new Chart(typeDistCtx, { type: 'doughnut', data: { labels: ['销售', '租赁', '劳动', '服务', '其他'], datasets: [{ data: [35, 25, 20, 15, 5], backgroundColor: ['#0052cc', '#28a745', '#ffc107', '#fd7e14', '#6c757d'], borderWidth: 2, borderColor: '#fff'}] }, options: { cutout: '60%', plugins: { legend: { position: 'right', labels: {boxWidth:10, padding:8, font:{size:11}} } } } });

        document.querySelectorAll('.sidebar ul li a').forEach(link => { 
            if (link.href.endsWith('dashboard_v3.html')) { 
                link.parentElement.classList.add('active'); 
            } 
        });