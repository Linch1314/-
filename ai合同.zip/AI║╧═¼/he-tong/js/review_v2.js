document.querySelectorAll('.sidebar ul li a').forEach(link => { 
            if (link.href.endsWith('review_v3.html')) { 
                link.parentElement.classList.add('active'); 
            }
        });

        const startReviewButton = document.getElementById('startReviewButton'); 
        const contractToReviewInput = document.getElementById('contractToReview');
        const reviewResultOutput = document.getElementById('reviewResultOutput'); 
        const reviewSummaryDiv = document.getElementById('reviewSummary');
        const issueCountBadge = document.getElementById('issueCountBadge');

        const issuesToDetect = [
            // Typos
            { pattern: /圆整(?!\S)/gi, replacement: "元整", type: "typo", explanation: "建议修改：错别字，应为“元整”。" },
            { pattern: /承当/gi, replacement: "承担", type: "typo", explanation: "建议修改：错别字，应为“承担”。" },
            { pattern: /甲仿/gi, replacement: "甲方", type: "typo", explanation: "建议修改：错别字，应为“甲方”。" },
            { pattern: /测式/gi, replacement: "测试", type: "typo", explanation: "建议修改：错别字，应为“测试”。" },
            
            // Potentially Unreasonable Clauses / Risky Keywords
            { pattern: /所有责任/gi, type: "unreasonable", explanation: "风险提示：“所有责任”表述可能过于绝对，建议明确责任范围和具体情形。" },
            { pattern: /单方面解除/gi, type: "unreasonable", explanation: "风险提示：“单方面解除”可能存在法律风险，需符合法定或约定条件。" },
            { pattern: /最终解释权/gi, type: "unreasonable", explanation: "风险提示：“最终解释权”条款在格式合同中可能被认定为无效，建议删除或修改。" },
            { pattern: /不可撤销地同意/gi, type: "unreasonable", explanation: "风险提示：“不可撤销”条款需谨慎使用，确保公平合理。" },
            { pattern: /放弃所有权利/gi, type: "unreasonable", explanation: "风险提示：“放弃所有权利”可能导致权利失衡，建议明确具体放弃的权利。" },
            { pattern: /赔偿上限过低/gi, type: "risky", explanation: "风险提示：赔偿上限设置是否合理，可能无法覆盖实际损失。" },
            { pattern: /免除其主要责任/gi, type: "risky", explanation: "风险提示：免除一方主要责任的条款可能无效。" },
            { pattern: /显失公平/gi, type: "risky", explanation: "风险提示：条款内容可能构成显失公平，存在被撤销或认定无效的风险。" },

            { pattern: /不明确/gi, type: "ambiguity", explanation: "风险提示：条款表述“不明确”，可能导致后续争议。" },
            { pattern: /含糊/gi, type: "ambiguity", explanation: "风险提示：条款内容“含糊”，建议具体化。" },
        ];

        startReviewButton.addEventListener('click', () => {
            const contractText = contractToReviewInput.value; 
            if (contractText.trim() === "") { 
                alert("请输入合同文本！"); 
                return; 
            }

            reviewResultOutput.innerHTML = ''; 
            reviewResultOutput.classList.add('loading'); 
            reviewSummaryDiv.style.display = 'none';
            reviewSummaryDiv.innerHTML = ''; 
            issueCountBadge.style.display = 'none';
            startReviewButton.disabled = true; 
            startReviewButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 正在审查...';
            
            setTimeout(() => {
                let highlightedText = contractText;
                let issuesFoundDetails = [];

                issuesToDetect.forEach(issue => {
                    const regex = new RegExp(issue.pattern.source, issue.pattern.flags); 
                    highlightedText = highlightedText.replace(regex, (match) => {
                        issuesFoundDetails.push({ 
                            text: match, 
                            type: issue.type, 
                            explanation: issue.explanation,
                            replacement: issue.replacement 
                        });
                       
                        return `<span class="highlight-issue" title="${issue.explanation}${issue.replacement ? ` (建议: ${issue.replacement})` : ''}">${match}</span>`;
                    });
                });

                reviewResultOutput.innerHTML = highlightedText;
                reviewResultOutput.classList.remove('loading');
                
                if (issuesFoundDetails.length > 0) {
                    issueCountBadge.textContent = issuesFoundDetails.length;
                    issueCountBadge.style.display = 'inline-block';

                    let summaryHTML = '<p><strong>智能审查摘要：</strong></p>';
                    summaryHTML += `<p>共检测到 <strong>${issuesFoundDetails.length}</strong> 处潜在问题/建议：</p><ul>`;
                    
                    const issueCountsByType = issuesFoundDetails.reduce((acc, issue) => {
                        acc[issue.type] = (acc[issue.type] || 0) + 1;
                        return acc;
                    }, {});

                    for (const type in issueCountsByType) {
                        summaryHTML += `<li>${translateIssueType(type)}: ${issueCountsByType[type]} 处</li>`;
                    }
                    summaryHTML += `</ul><p style="margin-top:10px;">请仔细核对合同中高亮标记的部分，并结合具体业务场景判断。本审查结果仅供参考，不构成法律意见。</p>`;
                    reviewSummaryDiv.innerHTML = summaryHTML;
                    reviewSummaryDiv.style.display = 'block';
                } else {
                     reviewSummaryDiv.innerHTML = '<p><strong>智能审查摘要：</strong></p><p>未检测到明显的预设风险点或错别字。建议仍需人工仔细核对。</p>';
                     reviewSummaryDiv.style.display = 'block';
                }


                startReviewButton.disabled = false; 
                startReviewButton.innerHTML = '<i class="fas fa-search-dollar"></i> 重新审查';

            }, 2200); 
        });

        function translateIssueType(type) {
            switch(type) {
                case 'typo': return '错别字/用词建议';
                case 'unreasonable': return '潜在不合理条款';
                case 'risky': return '高风险表述';
                case 'ambiguity': return '表述模糊';
                default: return '其他问题';
            }
        }