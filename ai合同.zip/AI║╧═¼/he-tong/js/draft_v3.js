 document.querySelectorAll('.sidebar ul li a').forEach(link => { 
            if (link.href.endsWith('draft_v3.html')) { 
                link.parentElement.classList.add('active'); 
            }
        });

        const draftButton = document.getElementById('draftButton'); 
        const contractOutput = document.getElementById('contractOutput');
        const contractTypeInput = document.getElementById('contractType'); 
        const keywordsInput = document.getElementById('keywords');
        const partyANameInput = document.getElementById('partyAName'); 
        const partyAContactInput = document.getElementById('partyAContact');
        const partyBNameInput = document.getElementById('partyBName'); 
        const partyBContactInput = document.getElementById('partyBContact');
        const copyButton = document.getElementById('copyButton'); 
        const downloadButton = document.getElementById('downloadButton');

        function fillPlaceholders(templateContent, partyA, partyB) {
            let filledContent = templateContent;
          
            filledContent = filledContent.replace(/\[甲方名称\]|\[单位全称\]|\[甲方公司\]/g, partyA.name || "甲方");
            filledContent = filledContent.replace(/\[乙方名称\]|\[员工姓名\]|\[乙方公司\]/g, partyB.name || "乙方");
           
            return filledContent;
        }


        window.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const templateName = urlParams.get('templateName');
            const templateContent = urlParams.get('templateContent');

            if (templateName) {
                contractTypeInput.value = templateName;
            }
            if (templateContent) {
                contractOutput.textContent = templateContent; 
               
            }
        });

        draftButton.addEventListener('click', () => {
            let initialContent = contractOutput.textContent;
            if (initialContent === "请在左侧输入合同要素并点击“开始智能起草”，或从模板库选择模板使用。") {
                initialContent = ""; // Start fresh if it's the placeholder
            }

            contractOutput.textContent = ''; 
            contractOutput.classList.add('loading'); 
            draftButton.disabled = true; 
            draftButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 正在起草...';
            
            const contractType = contractTypeInput.value || "未指定类型合同"; 
            const keywords = keywordsInput.value.split('\n').filter(k => k.trim() !== "");
            const partyAName = partyANameInput.value; 
            const partyAContact = partyAContactInput.value;
            const partyBName = partyBNameInput.value; 
            const partyBContact = partyBContactInput.value;

            if (initialContent) {
                 initialContent = fillPlaceholders(initialContent, 
                    { name: partyAName, contact: partyAContact }, 
                    { name: partyBName, contact: partyBContact }
                );
            }


            let generatedText = initialContent ? initialContent + "\n\n--- 以下为AI根据关键词补充或生成 --- \n\n" : "";
            const steps = initialContent ? [] : [ 
                `**${contractType}**\n\n`, 
                `甲方：${partyAName || '[甲方名称]'}\n联系方式：${partyAContact || '[甲方联系方式]'}\n\n`, 
                `乙方：${partyBName || '[乙方名称]'}\n联系方式：${partyBContact || '[乙方联系方式]'}\n\n`, 
                `**鉴于条款：**\n根据中华人民共和国相关法律法规，甲乙双方在平等自愿、协商一致的基础上，达成如下协议：\n\n`
            ];
            
            steps.push(`**一、核心约定：**\n`);
            keywords.forEach(k => steps.push(`  - ${k}\n`));
            
            if (!initialContent || keywords.length > 0) { // Add standard clauses if no template or if keywords are provided to supplement
                steps.push(
                    `\n**二、权利与义务（示例）：**\n  1. 甲方保证...\n  2. 乙方承诺...\n\n`, 
                    `**三、违约责任（示例）：**\n  任何一方违反本合同约定，应承担相应违约责任...\n\n`, 
                    `**四、争议解决（示例）：**\n  因本合同引起的或与本合同有关的任何争议，应友好协商解决...\n\n`, 
                    `**五、其他（示例）：**\n  本合同一式两份，甲乙双方各执一份，具有同等法律效力。自双方签字盖章之日起生效。\n\n\n`, 
                    `甲方签字/盖章：__________________\n日期：______年____月____日\n\n`, 
                    `乙方签字/盖章：__________________\n日期：______年____月____日`
                );
            }


            let currentStep = 0; 
            function addNextStep() { 
                if (currentStep < steps.length) { 
                    generatedText += steps[currentStep]; 
                    contractOutput.textContent = generatedText; 
                    contractOutput.scrollTop = contractOutput.scrollHeight; 
                    currentStep++; 
                    setTimeout(addNextStep, 200); 
                } else { 
                    if (steps.length === 0 && initialContent) { 
                         contractOutput.textContent = generatedText;
                    }
                    contractOutput.classList.remove('loading'); 
                    draftButton.disabled = false; 
                    draftButton.innerHTML = '<i class="fas fa-magic"></i> 智能起草/补充'; 
                } 
            } 
            setTimeout(() => {
                if (steps.length === 0 && initialContent) { 
                     contractOutput.textContent = generatedText;
                     contractOutput.classList.remove('loading'); 
                     draftButton.disabled = false; 
                     draftButton.innerHTML = '<i class="fas fa-magic"></i> 智能起草/补充'; 
                } else {
                    addNextStep();
                }
            }, 300);
        });

        copyButton.addEventListener('click', () => { 
            const textToCopy = contractOutput.textContent;
            if (textToCopy.length > 0 && textToCopy !== "请在左侧输入合同要素并点击“开始智能起草”，或从模板库选择模板使用。") { 
                navigator.clipboard.writeText(textToCopy).then(() => alert('合同内容已复制！')).catch(err => alert('复制失败: ' + err)); 
            } else { 
                alert('没有可复制的内容。');
            }
        });

        downloadButton.addEventListener('click', () => { 
            const textToDownload = contractOutput.textContent;
            if (textToDownload.length > 0 && textToDownload !== "请在左侧输入合同要素并点击“开始智能起草”，或从模板库选择模板使用。") { 
                const blob = new Blob([textToDownload], { type: 'text/plain;charset=utf-8' }); 
                const link = document.createElement('a'); 
                link.href = URL.createObjectURL(blob); 
                link.download = (contractTypeInput.value || '合同') + '.txt'; 
                document.body.appendChild(link); 
                link.click(); 
                document.body.removeChild(link); 
                URL.revokeObjectURL(link.href); 
            } else { 
                alert('没有可下载的内容。'); 
            }
        });