let initialTemplates = [
            { id: 1, name: "标准租赁合同", description: "适用于住宅或商业地产租赁，包含租金、押金、租期、双方权利义务等条款。", tags: ["租赁", "住宅", "通用"], content: "【标准租赁合同】\n\n甲方（出租方）：____________\n乙方（承租方）：____________\n\n根据《中华人民共和国合同法》及相关法律法规，甲乙双方在平等、自愿的基础上，就房屋租赁事宜达成如下协议：\n\n一、房屋基本情况...\n（后续条款）" },
            { id: 2, name: "劳动合同（标准版）", description: "符合最新劳动法规定，涵盖工作内容、工作地点、劳动报酬、合同期限、社会保险等。", tags: ["劳动", "人事", "标准"], content: "【劳动合同（标准版）】\n\n甲方（用人单位）：____________\n乙方（劳动者）：____________\n\n（后续条款）..." },
            { id: 3, name: "软件开发服务协议", description: "规定软件开发项目的范围、交付物、验收标准、费用支付、知识产权归属等。", tags: ["服务", "IT", "项目"], content: "【软件开发服务协议】\n\n委托方（甲方）：____________\n服务方（乙方）：____________\n\n（后续条款）..." }
        ];
        let templatesData = JSON.parse(localStorage.getItem('contractTemplates_v4')) || [...initialTemplates];
        let currentEditingCardId = null; 
        let currentModalTemplateId = null;

        const templateGrid = document.getElementById('templateGrid');
        const searchInput = document.getElementById('searchInput');
        const searchButton = document.getElementById('searchButton');
        const newTemplateBtn = document.getElementById('newTemplateBtn');
        const editModal = document.getElementById('editModal');
        const closeModalBtn = document.getElementById('closeModalBtn');
        const modalTitle = document.getElementById('modalTitle');
        const modalContentTextarea = document.getElementById('modalContentTextarea');
        const saveModalContentBtn = document.getElementById('saveModalContentBtn');
        const closeModalFooterBtn = document.getElementById('closeModalFooterBtn');
        const noResultsMessage = document.getElementById('noResultsMessage');

        function saveToLocalStorage() {
            localStorage.setItem('contractTemplates_v4', JSON.stringify(templatesData));
        }

        function renderTemplates(templatesToRender) {
            templateGrid.innerHTML = '';
            noResultsMessage.style.display = templatesToRender.length === 0 ? 'block' : 'none';

            templatesToRender.forEach(template => {
                const card = document.createElement('div');
                card.classList.add('template-card');
                card.dataset.templateId = template.id; 
                card.innerHTML = `
                    <h3 class="template-name" data-field="name">${template.name}</h3>
                    <p class="template-description" data-field="description">${template.description}</p>
                    <div class="tags">
                        ${template.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                    <div class="actions">
                        <button class="btn btn-outline-secondary btn-sm preview-btn"><i class="fas fa-eye"></i> 预览</button>
                        <button class="btn btn-warning btn-sm edit-card-btn"><i class="fas fa-edit"></i> 编辑信息</button>
                        <button class="btn btn-info btn-sm edit-content-btn"><i class="fas fa-file-alt"></i> 编辑内容</button>
                        <button class="btn btn-primary btn-sm use-btn" data-name="${template.name}"><i class="fas fa-check-circle"></i> 使用</button>
                        <button class="btn btn-danger btn-sm delete-btn"><i class="fas fa-trash-alt"></i> 删除</button>
                    </div>
                    <div class="edit-mode-actions">
                         <button class="btn btn-success btn-sm save-card-changes-btn"><i class="fas fa-save"></i> 保存</button>
                         <button class="btn btn-outline-secondary btn-sm cancel-card-edit-btn"><i class="fas fa-times"></i> 取消</button>
                    </div>
                `;
                templateGrid.appendChild(card);
            });
            attachActionListeners();
        }

        function makeEditable(element, isEditable) {
            element.contentEditable = isEditable;
            element.classList.toggle('editable', isEditable);
            if (isEditable) element.focus();
        }
        
        function toggleEditMode(card, enable) {
            const nameEl = card.querySelector('.template-name');
            const descEl = card.querySelector('.template-description');
            const normalActions = card.querySelector('.actions');
            const editActions = card.querySelector('.edit-mode-actions');

            makeEditable(nameEl, enable);
            makeEditable(descEl, enable);
            
            normalActions.style.display = enable ? 'none' : 'flex';
            editActions.style.display = enable ? 'flex' : 'none';
            
            if (enable) {
                currentEditingCardId = parseInt(card.dataset.templateId);
                card.dataset.originalName = nameEl.textContent;
                card.dataset.originalDescription = descEl.textContent;
            } else {
                currentEditingCardId = null;
                if (card.dataset.originalName) nameEl.textContent = card.dataset.originalName;
                if (card.dataset.originalDescription) descEl.textContent = card.dataset.originalDescription;
            }
        }

        function attachActionListeners() {
            document.querySelectorAll('.preview-btn').forEach(button => {
                button.addEventListener('click', (e) => handleModalOpen(e, 'preview'));
            });
            document.querySelectorAll('.edit-card-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    const card = e.currentTarget.closest('.template-card');
                    if (currentEditingCardId && currentEditingCardId !== parseInt(card.dataset.templateId)) {
                        const otherCard = templateGrid.querySelector(`.template-card[data-template-id="${currentEditingCardId}"]`);
                        if(otherCard) toggleEditMode(otherCard, false);
                    }
                    toggleEditMode(card, true);
                });
            });
            document.querySelectorAll('.edit-content-btn').forEach(button => {
                button.addEventListener('click', (e) => handleModalOpen(e, 'edit'));
            });
            document.querySelectorAll('.use-btn').forEach(button => {
                button.addEventListener('click', handleUse);
            });
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', handleDelete);
            });
             document.querySelectorAll('.save-card-changes-btn').forEach(button => {
                button.addEventListener('click', handleSaveCardChanges);
            });
            document.querySelectorAll('.cancel-card-edit-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    const card = e.currentTarget.closest('.template-card');
                    toggleEditMode(card, false);
                });
            });
        }
        
        function handleSaveCardChanges(event) {
            const card = event.currentTarget.closest('.template-card');
            const templateId = parseInt(card.dataset.templateId);
            const template = templatesData.find(t => t.id === templateId);

            if (template) {
                const newName = card.querySelector('.template-name').textContent.trim();
                const newDescription = card.querySelector('.template-description').textContent.trim();

                if (!newName) {
                    alert("模板名称不能为空！");
                    card.querySelector('.template-name').textContent = template.name; 
                    card.querySelector('.template-name').focus();
                    return;
                }
                template.name = newName;
                template.description = newDescription;
                saveToLocalStorage();
                toggleEditMode(card, false); 
                card.querySelector('.template-name').textContent = template.name; 
                card.querySelector('.template-description').textContent = template.description;
                alert("模板信息已更新。");
            }
        }

        function handleModalOpen(event, mode = 'preview') { 
            const card = event.currentTarget.closest('.template-card');
            currentModalTemplateId = parseInt(card.dataset.templateId);
            const template = templatesData.find(t => t.id === currentModalTemplateId);

            if (template) {
                if (mode === 'edit') {
                    modalTitle.textContent = `编辑内容: ${template.name}`;
                    modalContentTextarea.value = template.content || "";
                    modalContentTextarea.readOnly = false;
                    saveModalContentBtn.style.display = 'inline-block';
                } else { 
                    modalTitle.textContent = `预览: ${template.name}`;
                    modalContentTextarea.value = template.content || "此模板没有可预览的内容。";
                    modalContentTextarea.readOnly = true;
                    saveModalContentBtn.style.display = 'none';
                }
                editModal.style.display = 'block';
            }
        }
        
        saveModalContentBtn.addEventListener('click', () => {
            if (currentModalTemplateId !== null) {
                const template = templatesData.find(t => t.id === currentModalTemplateId);
                if (template) {
                    template.content = modalContentTextarea.value;
                    saveToLocalStorage();
                    alert(`模板 "${template.name}" 的内容已更新。`);
                    editModal.style.display = "none";
                    currentModalTemplateId = null;
                }
            }
        });

        function handleUse(event) {
            const templateName = event.currentTarget.dataset.name;
            alert(`使用模板: ${templateName}\n(实际应用中将跳转到起草页面并预填 '${templateName}')`);
        }

        function handleDelete(event) {
            const card = event.currentTarget.closest('.template-card');
            const templateId = parseInt(card.dataset.templateId);
            const template = templatesData.find(t => t.id === templateId);
            if (confirm(`确定要删除模板 "${template.name}" 吗？`)) {
                templatesData = templatesData.filter(t => t.id !== templateId);
                saveToLocalStorage();
                renderTemplates(templatesData); 
            }
        }
        
        function handleSearch() {
            const searchTerm = searchInput.value.toLowerCase().trim();
            const filteredTemplates = templatesData.filter(template => 
                template.name.toLowerCase().includes(searchTerm) ||
                template.description.toLowerCase().includes(searchTerm) ||
                template.tags.some(tag => tag.toLowerCase().includes(searchTerm))
            );
            renderTemplates(filteredTemplates);
        }

        searchButton.addEventListener('click', handleSearch);
        searchInput.addEventListener('keyup', (event) => {
            if (event.key === 'Enter' || !searchInput.value.trim()) { 
                handleSearch();
            }
        });
        
        newTemplateBtn.addEventListener('click', () => {
            const newName = prompt("请输入新模板的名称:", "新合同模板");
            if (newName && newName.trim() !== "") {
                const newId = templatesData.length > 0 ? Math.max(...templatesData.map(t => t.id)) + 1 : 1;
                const newTemplate = {
                    id: newId, name: newName.trim(), description: "请填写模板描述...", 
                    tags: ["新创建"], content: `【${newName.trim()}】\n\n# 请在此编辑模板内容...`
                };
                templatesData.unshift(newTemplate); 
                saveToLocalStorage();
                renderTemplates(templatesData);
                const newCard = templateGrid.querySelector(`.template-card[data-template-id="${newId}"]`);
                if(newCard) {
                    toggleEditMode(newCard, true);
                    newCard.querySelector('.template-name').focus();
                }
            }
        });

        const closeModal = () => {
            editModal.style.display = "none";
            currentModalTemplateId = null;
        }
        closeModalBtn.onclick = closeModal;
        closeModalFooterBtn.onclick = closeModal;
        window.onclick = function(event) {
            if (event.target == editModal) {
                closeModal();
            }
        }

        renderTemplates(templatesData);

        document.querySelectorAll('.sidebar ul li a').forEach(link => { 
            if (link.href.endsWith('templates_v4.html')) { link.parentElement.classList.add('active');} 
        });